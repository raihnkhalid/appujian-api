<?php
$nama = "MUHAMMAD RAIHAN KHALID";
$username = mb_substr($nama, 0, 3);
echo $username;
